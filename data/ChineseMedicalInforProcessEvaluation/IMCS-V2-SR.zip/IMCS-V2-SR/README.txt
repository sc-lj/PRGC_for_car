数据集下载文件为：IMCS-V2-SR.zip, 包括：
* IMCS-V2_train.json: 训练集，IMCS-V2 4个子任务共享
* IMCS-V2_dev.json: 验证集，IMCS-V2 4个子任务共享
* IMCS-V2_test.json: 测试集， IMCS-V2 4个子任务共享
* symptom_norm.csv：共包含331个归一化后的症状实体。
* IMCS-V2-SR_test.json: IMCS-V2-SR任务的提交文件，提交格式请参照example_pred.json。
* example_pred.json: 提交结果示例
* README.txt: 说明文件
