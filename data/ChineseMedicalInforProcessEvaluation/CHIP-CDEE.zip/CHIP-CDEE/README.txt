1. 文件列表:
* CHIP-CDEE_train.json: 训练集。
* CHIP-CDEE_dev.json: 验证集。
* CHIP-CDEE_test.json: 测试集。 选手提交时候需要将事件抽取结果补充到event字段，如果tendency为空设为""，character和anatomy_list为空设为[].
* example_gold.json: 标准答案示例。
* example_pred.json: 提交结果示例。
* README.txt: 说明文件。

2. 该任务提交的文件名为: CHIP-CDEE_test.json
