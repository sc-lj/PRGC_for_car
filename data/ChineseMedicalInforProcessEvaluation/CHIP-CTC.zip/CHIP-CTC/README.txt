1. Mainfest:
- category.xlsx: 44种临床筛选标准分类定义
- CHIP-CTC_train.json: 训练集 
- CHIP-CTC_dev.json: 验证集
- CHIP-CTC_test.json: 测试集, 注: 选手提交的时候需要为每条记录增加"label"字段。
- example_gold.json: 标准答案示例
- example_pred.json: 提交结果示例
- README.txt: 说明文件

2. 评估指标以Macro-F1值为准确

3. 该任务提交的文件名为：CHIP-CTC_test.json
