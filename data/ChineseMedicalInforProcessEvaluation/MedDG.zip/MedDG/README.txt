
Mainfest:
● entity_list: 实体列表，共160项。选手做预测的时候，需至少包含一个列表中的实体。
● MedDG_train.json: 训练集 
● MedDG_dev.json: 验证集
● MedDG_test.json: 测试集, 选手提交的时候需要为每条记录增加"output"字段。
● example_gold.json: 标准答案示例
● example_pred.json: 提交结果示例
● evaluate.py: 评测脚本，可供选手本地训练调试。
● README.txt: 说明文件

# How to run the evaluation script:
python3 evaluate.py example_pred.json example_golden.json
