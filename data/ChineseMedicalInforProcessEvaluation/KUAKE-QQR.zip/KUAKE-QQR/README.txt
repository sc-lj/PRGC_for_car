
1. Mainfest:
- KUAKE-QQR_train.json: 训练集 
- KUAKE-QQR_dev.json: 验证集
- KUAKE-QQR_test.json: 测试集，选手提交的时候需要为每条记录增加“label”字段
- example_gold.json: 标准答案示例
- example_pred.json: 提交结果示例
- README.txt: 说明文件

2. 评估指标以准确率为准

3. 该任务提交的文件名为：KUAKE-QQR_test.json
